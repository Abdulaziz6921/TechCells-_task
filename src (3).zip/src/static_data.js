export const employees = [
  {
    id: 1,
    name: "Ali Xalilov",
    pin: "4556",
  },
  {
    id: 2,
    name: "Vali Nabiyev",
    pin: "3245",
  },
  {
    id: 3,
    name: "John Doe",
    pin: "9876",
  },
  {
    id: 4,
    name: "John Smith",
    pin: "7886",
  },
  {
    id: 5,
    name: "Peter Nick",
    pin: "9325",
  },
];

export const admin = [
  {
    name: "Abdulaziz",
    email: "abdulaziztojibayev6@gmail.com",
    password: "3676921",
  },
];
