import React from 'react'

function Notfound() {
    return (
        <div>404 ERROR || PAGE NOTFOUND</div>
    )
}

export default Notfound